Note: this example no longer works with the latest version of Halide
and is not maintained.

If you want to try to reproduce the results,
we recommend starting with an [older release of
Halide](https://github.com/halide/Halide/releases/tag/release_2013_11_11).
Contributions welcome to update this to the support the latest version.

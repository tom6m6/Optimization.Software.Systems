# oneAPI - Data Parallel C++ course

This repo is used to show the examples in the course for better understand and try DPC++.

Have a fun and file issue for any quesitons.

